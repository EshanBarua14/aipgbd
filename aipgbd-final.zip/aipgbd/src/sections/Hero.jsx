import { useEffect, useRef, useState } from 'react';

const WORDS = ['Cinema.', 'Brands.', 'Stories.', 'Vision.', 'Impact.'];

export default function Hero({ db }) {
  const s = db.site;
  const words = s.heroWords?.length ? s.heroWords : WORDS;
  const [wordIdx, setWordIdx] = useState(0);
  const [wordVisible, setWordVisible] = useState(true);
  const [heroVisible, setHeroVisible] = useState(false); // 3s hold
  const [scrollY, setScrollY] = useState(0);
  const particlesRef = useRef(null);
  const videoId = s.heroVideoId || 'y5N8uoFZLd0';

  // 3-second visual dominance hold before text appears
  useEffect(() => {
    const t = setTimeout(() => setHeroVisible(true), 3000);
    return () => clearTimeout(t);
  }, []);

  // Scroll-linked parallax
  useEffect(() => {
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Word cycling
  useEffect(() => {
    if (!heroVisible) return;
    const interval = setInterval(() => {
      setWordVisible(false);
      setTimeout(() => { setWordIdx(i => (i + 1) % words.length); setWordVisible(true); }, 400);
    }, 2500);
    return () => clearInterval(interval);
  }, [heroVisible, words.length]);

  // Particles
  useEffect(() => {
    const canvas = particlesRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();
    const particles = Array.from({ length: 55 }, () => ({
      x: Math.random() * canvas.width, y: Math.random() * canvas.height,
      r: Math.random() * 1.4 + 0.3,
      vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25,
      color: ['rgba(0,229,255,', 'rgba(155,89,255,', 'rgba(224,64,251,'][Math.floor(Math.random() * 3)],
      alpha: Math.random() * 0.5 + 0.1,
    }));
    let raf;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = canvas.width; if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height; if (p.y > canvas.height) p.y = 0;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = p.color + p.alpha + ')'; ctx.fill();
      });
      raf = requestAnimationFrame(animate);
    };
    animate();
    window.addEventListener('resize', resize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);

  // Scroll-linked opacity/transform for content
  const contentOpacity = Math.max(0, 1 - scrollY / 400);
  const contentY = scrollY * 0.25;

  return (
    <section id="hero" className="hero">
      <canvas ref={particlesRef} className="hero__particles" />

      {/* YouTube muted loop bg */}
      <div className="hero__video-wrap">
        <iframe
          src={`https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&loop=1&playlist=${videoId}&controls=0&showinfo=0&rel=0&modestbranding=1&playsinline=1`}
          title="hero bg" frameBorder="0" allow="autoplay"
          className="hero__video-iframe"
        />
      </div>
      <div className="hero__overlay" />

      <div className="hero__orb hero__orb--1" />
      <div className="hero__orb hero__orb--2" />

      {/* Content — holds for 3s then fades in */}
      <div
        className="hero__content container"
        style={{
          opacity: heroVisible ? contentOpacity : 0,
          transform: `translateY(${heroVisible ? contentY : 20}px)`,
          transition: heroVisible ? 'opacity 0.05s linear' : 'opacity 1.2s cubic-bezier(0.16,1,0.3,1), transform 1.2s cubic-bezier(0.16,1,0.3,1)',
        }}
      >
        <div className="section-badge" style={{ display: 'inline-flex', marginBottom: '2rem' }}>
          <span className="hero__badge-dot" />
          <span className="t-label">Dhaka, Bangladesh · Est. 2026</span>
        </div>

        <h1 className="hero__title">
          <span className="hero__title-line1">ENGINEERING</span>
          <br />
          <span className="hero__title-line2 grad-text">THE INEVITABLE</span>
        </h1>

        {/* Scroll-morphed value prop */}
        <div className="hero__value">
          <span className="hero__we">We create</span>&nbsp;
          <span className={`hero__word grad-text ${wordVisible ? 'in' : 'out'}`}>
            {words[wordIdx]}
          </span>
          &nbsp;<span className="hero__suffix">AI-engineered.</span>
        </div>

        <p className="hero__sub">{s.heroSubtitle || '30-second unbroken cinematic shots from a single image — using Gemini, Grok, Suno, ElevenLabs & Claude. The production gap between ৳1,80,000 and ৳25,000 is our business.'}</p>

        <div className="hero__actions">
          <a href="#compare" className="btn-primary" data-hover>
            <span>{s.ctaPrimary || 'See the Difference'}</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </a>
          <a href="#contact" className="btn-ghost" data-hover>
            <span>{s.ctaSecondary || 'Start a Project'}</span>
          </a>
        </div>

        <div className="hero__stats">
          {(db.stats || []).map((stat, i) => (
            <div className="hero__stat" key={i}>
              <div className="hero__stat-num">
                <span className="grad-text">{stat.num}</span>
                <span className="hero__stat-unit">{stat.unit}</span>
              </div>
              <div className="t-label hero__stat-label">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll hint — always visible */}
      <div className="hero__scroll" style={{ opacity: heroVisible ? 0.4 : 0, transition: 'opacity 1s 3.5s' }}>
        <div className="hero__scroll-line" />
        <span className="t-label">Scroll</span>
      </div>

      <style>{`
        .hero { min-height:100vh; display:flex; align-items:center; position:relative; overflow:hidden; padding:9rem 0 5rem; }
        .hero__particles { position:absolute; inset:0; pointer-events:none; z-index:0; }
        .hero__video-wrap { position:absolute; inset:0; z-index:1; pointer-events:none; overflow:hidden; }
        .hero__video-iframe { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); width:177.78vh; min-width:100%; height:56.25vw; min-height:100%; opacity:0.4; }
        .hero__overlay { position:absolute; inset:0; z-index:2; background:linear-gradient(to bottom,rgba(5,9,20,0.6) 0%,rgba(5,9,20,0.4) 40%,rgba(5,9,20,0.85) 100%); }
        [data-theme="light"] .hero__overlay { background:linear-gradient(to bottom,rgba(5,9,20,0.75) 0%,rgba(5,9,20,0.55) 40%,rgba(5,9,20,0.9) 100%); }
        .hero__orb { position:absolute; border-radius:50%; filter:blur(80px); pointer-events:none; z-index:1; }
        .hero__orb--1 { width:500px; height:500px; background:radial-gradient(circle,rgba(0,229,255,0.1) 0%,transparent 70%); top:-100px; right:-100px; animation:orbFloat 8s ease-in-out infinite; }
        .hero__orb--2 { width:400px; height:400px; background:radial-gradient(circle,rgba(155,89,255,0.08) 0%,transparent 70%); bottom:0; left:-50px; animation:orbFloat 10s ease-in-out infinite reverse; }
        @keyframes orbFloat { 0%,100%{transform:translate(0,0) scale(1)}33%{transform:translate(30px,-20px) scale(1.05)}66%{transform:translate(-20px,15px) scale(0.95)} }

        .hero__content { position:relative; z-index:3; max-width:820px; will-change:opacity,transform; }
        .hero__badge-dot { width:6px; height:6px; border-radius:50%; background:var(--cyan); box-shadow:0 0 8px var(--cyan); animation:dotPulse 2s ease-in-out infinite; flex-shrink:0; }
        @keyframes dotPulse { 0%,100%{opacity:1;transform:scale(1)}50%{opacity:0.5;transform:scale(1.3)} }

        /* Scroll-linked title */
        .hero__title {
          font-family:'Outfit',sans-serif; font-weight:900; line-height:0.95;
          font-size:clamp(3rem,9vw,9.5rem); margin-bottom:1.25rem;
          text-shadow:0 2px 30px rgba(0,0,0,0.6);
          letter-spacing:-0.04em;
        }
        .hero__title-line1 { color:rgba(255,255,255,0.9); display:block; }
        .hero__title-line2 { display:block; }

        .hero__value {
          font-family:'Outfit',sans-serif; font-weight:300; font-size:clamp(1.1rem,2vw,1.5rem);
          margin-bottom:1.5rem; color:rgba(255,255,255,0.7); line-height:1.4;
        }
        .hero__we { color:rgba(255,255,255,0.5); }
        .hero__suffix { color:rgba(255,255,255,0.4); font-size:0.75em; }
        .hero__word { display:inline-block; transition:opacity 0.4s ease,transform 0.4s ease; font-weight:700; }
        .hero__word.in { opacity:1; transform:translateY(0); }
        .hero__word.out { opacity:0; transform:translateY(-12px); }

        .hero__sub { font-size:clamp(0.88rem,1.2vw,1rem); max-width:560px; margin-bottom:2.5rem; color:rgba(255,255,255,0.55); line-height:1.8; }
        .hero__actions { display:flex; gap:1rem; flex-wrap:wrap; margin-bottom:3.5rem; }
        .hero__stats { display:flex; gap:3rem; flex-wrap:wrap; padding-top:2.5rem; border-top:1px solid rgba(255,255,255,0.08); }
        .hero__stat-num { font-family:'Outfit',sans-serif; font-weight:800; font-size:2.8rem; line-height:1; margin-bottom:0.3rem; display:flex; align-items:baseline; gap:2px; }
        .hero__stat-unit { font-size:1.4rem; background:var(--grad-text); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
        .hero__stat-label { color:rgba(255,255,255,0.35) !important; font-size:0.62rem; }

        .hero__scroll { position:absolute; bottom:2.5rem; right:3rem; display:flex; flex-direction:column; align-items:center; gap:0.75rem; z-index:3; }
        .hero__scroll .t-label { color:rgba(255,255,255,0.5); }
        .hero__scroll-line { width:1px; height:50px; background:linear-gradient(to bottom,transparent,var(--cyan)); animation:scrollAnim 2s ease-in-out infinite; }
        @keyframes scrollAnim { 0%,100%{opacity:0.3}50%{opacity:1} }
        @media(max-width:600px){.hero__scroll{display:none}.hero__stats{gap:1.5rem}}
      `}</style>
    </section>
  );
}
