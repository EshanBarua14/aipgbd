import { useState, useRef, useEffect, useCallback } from 'react';

const EXAMPLES = [
  {
    id: 'realestate',
    label: 'Real Estate',
    color: '#00E5FF',
    before: {
      type: 'prompt',
      title: 'Raw Input',
      content: `> Gemini prompt submitted:\n\n"Luxury apartment interior,\nDhaka Bangladesh, modern,\nphone photo quality"\n\n> Result: Generic stock-\n  photo aesthetic.\n  No character.\n  No brand identity.\n\n> Client budget used: ৳0\n> Production time: 2 min\n> Conversion rate: ~2%`,
    },
    after: {
      type: 'result',
      title: 'AIPGBD Output',
      content: 'Arri Alexa · Anamorphic · Golden Hour · 8K · 30s unbroken take · Custom Suno score · ElevenLabs VO',
      stats: [{ v: '৳45,000', l: 'Package price' }, { v: '48h', l: 'Delivery' }, { v: '~34%', l: 'Conversion lift' }],
    },
  },
  {
    id: 'fintech',
    label: 'Fintech Brand',
    color: '#9B59FF',
    before: {
      type: 'prompt',
      title: 'Raw Input',
      content: `> Grok prompt submitted:\n\n"Professional man in office,\nholding phone, smiling,\nfintech app on screen"\n\n> Result: Generic corporate\n  stock photo.\n  Zero brand identity.\n  Interchangeable.\n\n> Client budget used: ৳0\n> Production time: 3 min\n> Investor confidence: Low`,
    },
    after: {
      type: 'result',
      title: 'AIPGBD Output',
      content: 'Consistent character seed · Rembrandt lighting · Holographic UI overlay · 30s motion · Voice narration',
      stats: [{ v: '৳25,000', l: 'Brand Engine' }, { v: '72h', l: 'Full kit' }, { v: 'Investor-grade', l: 'Output quality' }],
    },
  },
  {
    id: 'restaurant',
    label: 'F&B Content',
    color: '#E040FB',
    before: {
      type: 'prompt',
      title: 'Raw Input',
      content: `> Phone photo submitted:\n\n3.jpg — 2.4MB\nJPEG, auto-HDR\nFlat lay, overhead\nAverage lighting\n\n> Result: Looks like\n  every other restaurant\n  Instagram post.\n  Scroll-stop rate: ~1%\n\n> Shoot cost: ৳40,000\n> Content pieces: 1\n> Monthly volume: 1`,
    },
    after: {
      type: 'result',
      title: 'AIPGBD Output',
      content: 'Macro cinematic · Steam dynamics · Warm key light · Custom ambient score · 8 pieces/month',
      stats: [{ v: '৳15,000', l: 'Monthly retainer' }, { v: '8 videos', l: 'Per month' }, { v: '~12%', l: 'Scroll-stop rate' }],
    },
  },
];

function BeforePanel({ example }) {
  const [lines, setLines] = useState([]);
  const content = example.before.content;

  useEffect(() => {
    setLines([]);
    const allLines = content.split('\n');
    allLines.forEach((line, i) => {
      setTimeout(() => {
        setLines(prev => [...prev, line]);
      }, i * 80);
    });
  }, [content]);

  return (
    <div className="ba-panel ba-panel--before">
      <div className="ba-panel__header">
        <div className="ba-panel__dot ba-panel__dot--before" />
        <span className="ba-panel__label t-label">BEFORE — {example.before.title}</span>
      </div>
      <div className="ba-terminal">
        <div className="ba-terminal__bar">
          <div className="ba-terminal__circle" style={{ background: '#FF5F57' }} />
          <div className="ba-terminal__circle" style={{ background: '#FEBC2E' }} />
          <div className="ba-terminal__circle" style={{ background: '#28C840' }} />
          <span style={{ marginLeft: 8, fontFamily: 'JetBrains Mono, monospace', fontSize: '0.6rem', color: 'rgba(255,255,255,0.3)', letterSpacing: '0.1em' }}>
            raw-input.txt
          </span>
        </div>
        <div className="ba-terminal__body">
          {lines.map((line, i) => (
            <div key={i} className="ba-terminal__line" style={{
              color: line.startsWith('>') ? 'rgba(255,255,255,0.5)' :
                     line.includes('৳') ? '#F59E0B' :
                     line.includes('%') ? '#E040FB' :
                     line.trim() === '' ? 'transparent' :
                     'rgba(255,255,255,0.25)',
            }}>
              {line || '\u00A0'}
            </div>
          ))}
          {lines.length < content.split('\n').length && (
            <div className="ba-cursor" />
          )}
        </div>
      </div>
    </div>
  );
}

function AfterPanel({ example }) {
  return (
    <div className="ba-panel ba-panel--after" style={{ '--after-color': example.color }}>
      <div className="ba-panel__header">
        <div className="ba-panel__dot ba-panel__dot--after" style={{ background: example.color, boxShadow: `0 0 8px ${example.color}` }} />
        <span className="ba-panel__label t-label" style={{ color: example.color }}>AFTER — {example.after.title}</span>
      </div>
      <div className="ba-result">
        <div className="ba-result__glow" style={{ background: `radial-gradient(circle, ${example.color}20 0%, transparent 70%)` }} />
        <div className="ba-result__screen">
          <div className="ba-result__play">
            <svg width="28" height="28" viewBox="0 0 24 24" fill={example.color}><polygon points="5 3 19 12 5 21 5 3"/></svg>
          </div>
          <div className="ba-result__badge" style={{ borderColor: `${example.color}40`, color: example.color }}>
            30s · 4K · Unbroken take
          </div>
        </div>
        <div className="ba-result__tags">
          {example.after.content.split(' · ').map((tag, i) => (
            <span key={i} className="ba-result__tag" style={{ borderColor: `${example.color}30`, color: `${example.color}CC` }}>
              {tag}
            </span>
          ))}
        </div>
        <div className="ba-result__stats">
          {example.after.stats.map((s, i) => (
            <div key={i} className="ba-result__stat">
              <div className="ba-result__stat-val" style={{ color: example.color }}>{s.v}</div>
              <div className="ba-result__stat-label t-label">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function BeforeAfter() {
  const [active, setActive] = useState(0);
  const [sliderX, setSliderX] = useState(50);
  const [dragging, setDragging] = useState(false);
  const containerRef = useRef(null);

  const onMouseMove = useCallback((e) => {
    if (!dragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(15, Math.min(85, ((e.clientX - rect.left) / rect.width) * 100));
    setSliderX(x);
  }, [dragging]);

  const onTouchMove = useCallback((e) => {
    if (!dragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(15, Math.min(85, ((e.touches[0].clientX - rect.left) / rect.width) * 100));
    setSliderX(x);
  }, [dragging]);

  useEffect(() => {
    if (dragging) {
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', () => setDragging(false));
      window.addEventListener('touchmove', onTouchMove);
      window.addEventListener('touchend', () => setDragging(false));
    }
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', () => setDragging(false));
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', () => setDragging(false));
    };
  }, [dragging, onMouseMove, onTouchMove]);

  const example = EXAMPLES[active];

  return (
    <section id="compare" className="section compare">
      <div className="container">
        <div className="section-header reveal">
          <div className="section-badge"><span className="t-label">The Proof</span></div>
          <h2 className="t-heading" style={{ fontSize: 'clamp(2rem,4vw,3.5rem)', marginBottom: '0.75rem' }}>
            Raw prompt.<br /><span className="grad-text">Cinematic output.</span>
          </h2>
          <p className="t-body" style={{ maxWidth: '500px', fontSize: '0.9rem' }}>
            This is what the gap looks like. Left side: the raw input any tool generates. Right side: what AIPGBD delivers. Drag the divider.
          </p>
        </div>

        {/* Category switcher */}
        <div className="ba-tabs reveal">
          {EXAMPLES.map((ex, i) => (
            <button
              key={ex.id}
              className={`ba-tab ${active === i ? 'active' : ''}`}
              onClick={() => { setActive(i); setSliderX(50); }}
              style={active === i ? { borderColor: ex.color, color: ex.color } : {}}
              data-hover
            >
              {ex.label}
            </button>
          ))}
        </div>

        {/* Split view with drag slider */}
        <div className="ba-container reveal reveal-delay-2" ref={containerRef}>
          {/* Before panel (left, clipped) */}
          <div className="ba-left" style={{ width: `${sliderX}%` }}>
            <BeforePanel example={example} key={`before-${active}`} />
          </div>

          {/* After panel (right, full width underneath) */}
          <div className="ba-right">
            <AfterPanel example={example} key={`after-${active}`} />
          </div>

          {/* Drag handle */}
          <div
            className="ba-handle"
            style={{ left: `${sliderX}%` }}
            onMouseDown={() => setDragging(true)}
            onTouchStart={() => setDragging(true)}
          >
            <div className="ba-handle__line" />
            <div className="ba-handle__knob">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="15 18 9 12 15 6"/>
              </svg>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </div>
            <div className="ba-handle__line" />
          </div>

          {/* Labels */}
          <div className="ba-label ba-label--before">
            <span className="t-label" style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.58rem' }}>BEFORE</span>
          </div>
          <div className="ba-label ba-label--after" style={{ color: example.color }}>
            <span className="t-label" style={{ fontSize: '0.58rem' }}>AFTER</span>
          </div>
        </div>

        {/* CTA */}
        <div className="ba-cta reveal">
          <p className="t-label" style={{ color: 'var(--text-tertiary)', marginBottom: '1rem' }}>
            The gap between these two outputs is ৳{active === 0 ? '45,000' : active === 1 ? '25,000' : '15,000'} and {active === 0 ? '48 hours' : active === 1 ? '72 hours' : '1 month retainer'}.
          </p>
          <a href="#contact" className="btn-primary" data-hover>
            <span>Get This for Your Brand</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </a>
        </div>
      </div>

      <style>{`
        .ba-tabs { display: flex; gap: 0.75rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
        .ba-tab {
          padding: 0.5rem 1.25rem; background: var(--surface); border: 1px solid var(--border);
          border-radius: 100px; font-family: 'Space Grotesk', sans-serif; font-size: 0.8rem;
          font-weight: 500; color: var(--text-secondary); cursor: none; transition: all 0.2s;
        }
        .ba-tab:hover { border-color: var(--border-strong); color: var(--text-primary); }
        .ba-tab.active { font-weight: 600; background: var(--surface-2); }

        .ba-container {
          position: relative; height: 420px; border: 1px solid var(--border);
          border-radius: 12px; overflow: hidden; user-select: none;
          cursor: col-resize;
        }

        .ba-left {
          position: absolute; top: 0; left: 0; height: 100%;
          overflow: hidden; z-index: 2;
          transition: width 0s;
        }
        .ba-left > * { width: 100vw; max-width: 1200px; height: 100%; }

        .ba-right {
          position: absolute; top: 0; left: 0; right: 0; height: 100%; z-index: 1;
        }
        .ba-right > * { height: 100%; }

        /* Handle */
        .ba-handle {
          position: absolute; top: 0; height: 100%; z-index: 10;
          transform: translateX(-50%); display: flex; flex-direction: column;
          align-items: center; cursor: col-resize;
        }
        .ba-handle__line { flex: 1; width: 2px; background: rgba(255,255,255,0.8); }
        .ba-handle__knob {
          width: 40px; height: 40px; border-radius: 50%;
          background: #fff; display: flex; align-items: center; justify-content: center;
          color: #111; flex-shrink: 0; box-shadow: 0 2px 16px rgba(0,0,0,0.3);
          gap: 0;
        }
        .ba-handle__knob svg { flex-shrink: 0; }

        /* Labels */
        .ba-label {
          position: absolute; bottom: 1rem; z-index: 5; pointer-events: none;
        }
        .ba-label--before { left: 1rem; }
        .ba-label--after { right: 1rem; }

        /* Panels */
        .ba-panel { height: 100%; display: flex; flex-direction: column; }
        .ba-panel--before { background: #0A0F0A; }
        .ba-panel--after {
          background: var(--bg-2);
          position: relative; overflow: hidden;
        }

        .ba-panel__header {
          display: flex; align-items: center; gap: 0.6rem; padding: 0.875rem 1.25rem;
          border-bottom: 1px solid rgba(255,255,255,0.06); flex-shrink: 0;
        }
        .ba-panel__dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
        .ba-panel__dot--before { background: rgba(255,255,255,0.2); }
        .ba-panel__label { font-size: 0.6rem; color: rgba(255,255,255,0.35); }
        .ba-panel--after .ba-panel__label { }

        /* Terminal */
        .ba-terminal { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .ba-terminal__bar {
          display: flex; align-items: center; gap: 6px; padding: 0.6rem 1rem;
          background: rgba(255,255,255,0.02); border-bottom: 1px solid rgba(255,255,255,0.04);
          flex-shrink: 0;
        }
        .ba-terminal__circle { width: 10px; height: 10px; border-radius: 50%; }
        .ba-terminal__body {
          flex: 1; padding: 1rem 1.25rem; font-family: 'JetBrains Mono', monospace;
          font-size: 0.72rem; line-height: 1.9; overflow: hidden;
        }
        .ba-terminal__line { white-space: pre; }
        .ba-cursor {
          width: 7px; height: 14px; background: rgba(255,255,255,0.4);
          animation: blink 1s step-end infinite; margin-top: 2px;
        }
        @keyframes blink { 0%,100%{opacity:1}50%{opacity:0} }

        /* Result panel */
        .ba-result {
          height: 100%; display: flex; flex-direction: column;
          padding: 1.25rem; gap: 1.25rem; position: relative; overflow: hidden;
        }
        .ba-result__glow {
          position: absolute; width: 300px; height: 300px;
          top: -100px; right: -100px; border-radius: 50%; filter: blur(60px);
          pointer-events: none;
        }
        .ba-result__screen {
          flex: 1; background: var(--bg-3); border: 1px solid var(--border);
          border-radius: 8px; display: flex; flex-direction: column;
          align-items: center; justify-content: center; gap: 1rem;
          position: relative;
        }
        .ba-result__play {
          width: 64px; height: 64px; border-radius: 50%;
          border: 1px solid var(--after-color, var(--cyan));
          display: flex; align-items: center; justify-content: center;
          background: rgba(0,0,0,0.4);
          box-shadow: 0 0 30px var(--after-color, var(--cyan)), 0 0 60px rgba(0,0,0,0.3);
          animation: playPulse 3s ease-in-out infinite;
        }
        @keyframes playPulse { 0%,100%{box-shadow:0 0 20px var(--after-color,var(--cyan))} 50%{box-shadow:0 0 40px var(--after-color,var(--cyan)),0 0 80px var(--after-color,var(--cyan))40} }
        .ba-result__badge {
          font-family: 'JetBrains Mono', monospace; font-size: 0.6rem;
          letter-spacing: 0.12em; text-transform: uppercase;
          border: 1px solid; border-radius: 100px; padding: 0.25rem 0.75rem;
        }
        .ba-result__tags {
          display: flex; flex-wrap: wrap; gap: 0.4rem;
        }
        .ba-result__tag {
          font-family: 'JetBrains Mono', monospace; font-size: 0.6rem;
          letter-spacing: 0.08em; border: 1px solid; border-radius: 4px;
          padding: 0.2rem 0.5rem;
        }
        .ba-result__stats {
          display: flex; gap: 1.5rem; padding-top: 0.875rem;
          border-top: 1px solid var(--border);
        }
        .ba-result__stat-val {
          font-family: 'Outfit', sans-serif; font-weight: 800; font-size: 1.2rem; line-height: 1.2;
        }
        .ba-result__stat-label { font-size: 0.58rem; color: var(--text-tertiary); margin-top: 0.15rem; }

        .ba-cta { text-align: center; margin-top: 2rem; }

        @media (max-width: 600px) {
          .ba-container { height: 500px; }
        }
      `}</style>
    </section>
  );
}
