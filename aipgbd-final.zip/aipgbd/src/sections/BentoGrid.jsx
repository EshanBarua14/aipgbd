import { useState, useEffect, useRef } from 'react';

/* ── Live clock ── */
function LiveClock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.72rem', color: 'var(--cyan)' }}>
      {time.toLocaleTimeString('en-US', { hour12: false })} BST
    </span>
  );
}

/* ── Typing code snippet ── */
const CODE_SNIPPETS = [
  {
    lang: 'python',
    color: '#4285F4',
    label: 'Gemini Visual Anchor',
    lines: [
      '# AIPGBD — Visual Anchor Engine',
      'import google.generativeai as genai',
      '',
      'prompt = """',
      '  Arri Alexa 65, anamorphic lens,',
      '  golden hour Dhaka skyline,',
      '  8K, teal-orange grade',
      '"""',
      '',
      'model = genai.GenerativeModel("gemini-1.5-pro")',
      'response = model.generate_content(prompt)',
      '# → Hyper-realistic base image generated',
    ],
  },
  {
    lang: 'typescript',
    color: '#00C2FF',
    label: 'Grok Motion Extension',
    lines: [
      '// AIPGBD — Anchor-and-Extend Method',
      'const extend = async (anchorImage: string) => {',
      '  const config = {',
      '    duration: 30,    // seconds',
      '    fps: 24,         // cinematic',
      '    motion: "slow_push_in",',
      '    consistency: "high",',
      '  };',
      '  const video = await grok.video.extend({',
      '    image: anchorImage,',
      '    ...config,',
      '  });',
      '  return video; // 30s, no cuts',
      '};',
    ],
  },
  {
    lang: 'csharp',
    color: '#9B59FF',
    label: 'ASP.NET Portal API',
    lines: [
      '// AIPGBD — Project Status Hub',
      '[ApiController]',
      'public class ProjectHub : Hub {',
      '  public async Task StreamStatus(',
      '    string projectId) {',
      '    var phases = new[] {',
      '      "Data Ingestion",',
      '      "AI Synthesis",',
      '      "Final Grade",',
      '      "Ready for Review"',
      '    };',
      '    foreach (var phase in phases) {',
      '      await Clients.Caller',
      '        .SendAsync("Update", phase);',
      '    }',
      '  }',
      '}',
    ],
  },
];

function CodeSnippet() {
  const [snippetIdx, setSnippetIdx] = useState(0);
  const [visibleLines, setVisibleLines] = useState([]);
  const [lineIdx, setLineIdx] = useState(0);

  const snippet = CODE_SNIPPETS[snippetIdx];

  useEffect(() => {
    setVisibleLines([]);
    setLineIdx(0);
  }, [snippetIdx]);

  useEffect(() => {
    if (lineIdx >= snippet.lines.length) {
      // Cycle to next after 3s pause
      const t = setTimeout(() => {
        setSnippetIdx(i => (i + 1) % CODE_SNIPPETS.length);
      }, 3000);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => {
      setVisibleLines(prev => [...prev, snippet.lines[lineIdx]]);
      setLineIdx(i => i + 1);
    }, lineIdx === 0 ? 400 : 120);
    return () => clearTimeout(t);
  }, [lineIdx, snippetIdx, snippet.lines]);

  return (
    <div className="bento-code">
      <div className="bento-code__header">
        <div className="bento-code__circles">
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#FF5F57' }} />
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#FEBC2E' }} />
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#28C840' }} />
        </div>
        <span className="t-label" style={{ color: snippet.color, fontSize: '0.6rem' }}>{snippet.label}</span>
        <div style={{ display: 'flex', gap: '0.3rem', marginLeft: 'auto' }}>
          {CODE_SNIPPETS.map((_, i) => (
            <div key={i} style={{ width: i === snippetIdx ? 16 : 6, height: 6, borderRadius: 3, background: i === snippetIdx ? snippet.color : 'var(--border-strong)', transition: 'all 0.3s', cursor: 'pointer' }}
              onClick={() => setSnippetIdx(i)} />
          ))}
        </div>
      </div>
      <div className="bento-code__body">
        {visibleLines.map((line, i) => (
          <div key={i} className="bento-code__line" style={{
            color: line.startsWith('//') || line.startsWith('#') ? 'rgba(150,175,220,0.4)' :
                   line.includes('"""') || line.includes("'") ? '#E040FB' :
                   line.includes('await') || line.includes('async') ? '#00C2FF' :
                   line.includes('return') ? '#9B59FF' :
                   'rgba(200,215,255,0.75)',
          }}>
            <span style={{ color: 'rgba(150,175,220,0.25)', userSelect: 'none', marginRight: 12, minWidth: 20, display: 'inline-block', textAlign: 'right' }}>
              {i + 1}
            </span>
            {line || '\u00A0'}
          </div>
        ))}
        {lineIdx < snippet.lines.length && (
          <div className="bento-cursor" />
        )}
      </div>
    </div>
  );
}

/* ── System status ── */
const STATUS_ITEMS = [
  { label: 'Gemini API', status: 'operational', latency: '142ms' },
  { label: 'Grok Video', status: 'operational', latency: '89ms' },
  { label: 'ElevenLabs', status: 'operational', latency: '67ms' },
  { label: 'Suno v4', status: 'operational', latency: '203ms' },
  { label: 'Claude API', status: 'operational', latency: '55ms' },
];

function SystemStatus() {
  const [latencies, setLatencies] = useState(STATUS_ITEMS.map(s => parseInt(s.latency)));
  const [uptime] = useState('99.97%');

  useEffect(() => {
    const t = setInterval(() => {
      setLatencies(prev => prev.map(l => l + Math.floor((Math.random() - 0.5) * 30)));
    }, 2000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="bento-status">
      <div className="bento-status__header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <div className="bento-status__pulse" />
          <span className="t-label" style={{ color: '#22C55E', fontSize: '0.6rem' }}>ALL SYSTEMS OPERATIONAL</span>
        </div>
        <LiveClock />
      </div>
      <div className="bento-status__items">
        {STATUS_ITEMS.map((item, i) => (
          <div key={i} className="bento-status__item">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#22C55E', flexShrink: 0 }} />
              <span style={{ fontSize: '0.78rem', color: 'var(--text-secondary)' }}>{item.label}</span>
            </div>
            <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.68rem', color: latencies[i] > 300 ? '#F59E0B' : '#22C55E' }}>
              {latencies[i]}ms
            </span>
          </div>
        ))}
      </div>
      <div className="bento-status__footer">
        <div>
          <div style={{ fontSize: '0.65rem', color: 'var(--text-tertiary)', marginBottom: '0.2rem' }}>30-day uptime</div>
          <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.4rem', color: '#22C55E' }}>{uptime}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '0.65rem', color: 'var(--text-tertiary)', marginBottom: '0.2rem' }}>Active projects</div>
          <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.4rem', color: 'var(--cyan)' }}>7</div>
        </div>
      </div>
    </div>
  );
}

/* ── Render preview card ── */
function RenderCard({ color, label, tag, sub }) {
  return (
    <div className="bento-render" style={{ '--render-color': color }}>
      <div className="bento-render__bg" />
      <div className="bento-render__grid" />
      <div className="bento-render__content">
        <div className="bento-render__tag t-label" style={{ color, borderColor: `${color}40` }}>{tag}</div>
        <div className="bento-render__play">
          <svg width="16" height="16" viewBox="0 0 24 24" fill={color}><polygon points="5 3 19 12 5 21 5 3"/></svg>
        </div>
        <div>
          <div style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 700, fontSize: '0.95rem', color: 'var(--text-primary)', marginBottom: '0.2rem' }}>{label}</div>
          <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.6rem', color: 'var(--text-tertiary)', letterSpacing: '0.08em' }}>{sub}</div>
        </div>
      </div>
      <div className="bento-render__badge">30s · 4K</div>
    </div>
  );
}

/* ── Pipeline ticker ── */
const PIPELINE_STEPS = [
  { step: '01', label: 'Gemini anchor', status: 'complete', color: '#4285F4' },
  { step: '02', label: 'Grok motion', status: 'rendering', color: '#00C2FF' },
  { step: '03', label: 'Suno score', status: 'queued', color: '#FF6B35' },
  { step: '04', label: 'ElevenLabs VO', status: 'queued', color: '#A855F7' },
  { step: '05', label: 'Final delivery', status: 'queued', color: '#D4A853' },
];

function Pipeline() {
  const [progress, setProgress] = useState(62);

  useEffect(() => {
    const t = setInterval(() => {
      setProgress(p => p >= 99 ? 62 : p + 0.3);
    }, 150);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="bento-pipeline">
      <div className="bento-pipeline__header">
        <span className="t-label" style={{ fontSize: '0.6rem' }}>Live Pipeline</span>
        <span className="t-label" style={{ color: '#F59E0B', fontSize: '0.6rem' }}>NexaFinance Brand Film</span>
      </div>
      <div className="bento-pipeline__steps">
        {PIPELINE_STEPS.map((s, i) => (
          <div key={i} className="bento-pipeline__step">
            <div className="bento-pipeline__step-dot" style={{
              background: s.status === 'complete' ? s.color : s.status === 'rendering' ? 'transparent' : 'transparent',
              borderColor: s.color,
              boxShadow: s.status === 'rendering' ? `0 0 8px ${s.color}` : 'none',
              animation: s.status === 'rendering' ? 'stepPulse 1.5s ease-in-out infinite' : 'none',
            }} />
            <span style={{ fontSize: '0.75rem', color: s.status === 'queued' ? 'var(--text-tertiary)' : 'var(--text-primary)', flex: 1 }}>
              {s.label}
            </span>
            <span className="t-label" style={{
              fontSize: '0.58rem',
              color: s.status === 'complete' ? '#22C55E' : s.status === 'rendering' ? '#F59E0B' : 'var(--text-tertiary)',
            }}>
              {s.status}
            </span>
          </div>
        ))}
      </div>
      <div className="bento-pipeline__progress">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
          <span className="t-label" style={{ fontSize: '0.58rem', color: 'var(--text-tertiary)' }}>Render progress</span>
          <span className="t-label" style={{ fontSize: '0.58rem', color: '#00C2FF' }}>{Math.round(progress)}%</span>
        </div>
        <div style={{ height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${progress}%`, background: 'linear-gradient(90deg, #00C2FF, #9B59FF)', borderRadius: 2, transition: 'width 0.3s linear' }} />
        </div>
      </div>
    </div>
  );
}

/* ── Stack badge ── */
function StackBadge({ name, color, icon }) {
  return (
    <div className="bento-badge" style={{ '--badge-color': color }}>
      <span style={{ fontSize: '1rem' }}>{icon}</span>
      <span style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 600, fontSize: '0.8rem', color: 'var(--text-primary)' }}>{name}</span>
      <div className="bento-badge__dot" />
    </div>
  );
}

/* ── MAIN BENTO ── */
export default function BentoGrid() {
  return (
    <section id="bento" className="section bento">
      <div className="container">
        <div className="section-header reveal">
          <div className="section-badge"><span className="t-label">Infrastructure</span></div>
          <h2 className="t-heading" style={{ fontSize: 'clamp(2rem,4vw,3.5rem)', marginBottom: '0.75rem' }}>
            Live production.<br /><span className="grad-text">Right now.</span>
          </h2>
          <p className="t-body" style={{ maxWidth: '480px', fontSize: '0.9rem' }}>
            Every tool is live, monitored, and running at commercial tier. This is not a demo environment.
          </p>
        </div>

        <div className="bento-grid reveal">
          {/* Row 1: Code (large) + Status (medium) */}
          <div className="bento-cell bento-cell--code">
            <CodeSnippet />
          </div>
          <div className="bento-cell bento-cell--status">
            <SystemStatus />
          </div>

          {/* Row 2: Render cards + Pipeline */}
          <div className="bento-cell bento-cell--render1">
            <RenderCard color="#00E5FF" label="NEXARA Fintech" tag="Fintech" sub="Gemini → Grok → Suno · 30s" />
          </div>
          <div className="bento-cell bento-cell--render2">
            <RenderCard color="#9B59FF" label="Bashundhara Tower" tag="Real Estate" sub="Architectural render → 4K" />
          </div>
          <div className="bento-cell bento-cell--pipeline">
            <Pipeline />
          </div>

          {/* Row 3: Stack badges + CTA */}
          <div className="bento-cell bento-cell--stack">
            <div className="bento-stack">
              <div className="t-label" style={{ color: 'var(--text-tertiary)', marginBottom: '1rem', fontSize: '0.6rem' }}>Production Stack</div>
              <div className="bento-stack__badges">
                <StackBadge name="Gemini" color="#4285F4" icon="🎨" />
                <StackBadge name="Grok" color="#00C2FF" icon="🎬" />
                <StackBadge name="Suno v4" color="#FF6B35" icon="🎵" />
                <StackBadge name="ElevenLabs" color="#A855F7" icon="🎙️" />
                <StackBadge name="Claude" color="#D4A853" icon="🧠" />
              </div>
              <div style={{ marginTop: 'auto', paddingTop: '1rem', borderTop: '1px solid var(--border)' }}>
                <div className="t-label" style={{ color: 'var(--text-tertiary)', fontSize: '0.58rem', marginBottom: '0.3rem' }}>Commercial tier · No watermarks</div>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                  {['Full rights', 'No attribution', 'Broadcast ready'].map(t => (
                    <span key={t} style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.6rem', color: 'var(--cyan)', background: 'var(--cyan-dim)', border: '1px solid var(--cyan-border)', borderRadius: 4, padding: '0.2rem 0.5rem' }}>{t}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="bento-cell bento-cell--cta">
            <div className="bento-cta">
              <div className="bento-cta__orb" />
              <div className="t-label" style={{ color: 'var(--cyan)', marginBottom: '0.75rem', fontSize: '0.62rem' }}>✦ First 3 brands</div>
              <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.4rem', lineHeight: 1.2, marginBottom: '0.75rem', color: 'var(--text-primary)' }}>
                Free demo render
              </h3>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '1.25rem', lineHeight: 1.6 }}>
                See your brand in 30-second cinematic motion before committing. Zero risk.
              </p>
              <a href="#contact" className="btn-primary" data-hover style={{ width: '100%', justifyContent: 'center', fontSize: '0.78rem' }}>
                <span>Request Demo</span>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </a>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .bento-grid {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          grid-template-rows: auto auto auto;
          gap: 1rem;
        }
        .bento-cell {
          background: var(--surface); border: 1px solid var(--border);
          border-radius: 12px; overflow: hidden;
          transition: border-color 0.3s, box-shadow 0.3s;
        }
        .bento-cell:hover { border-color: var(--border-strong); }

        .bento-cell--code { grid-column: 1 / 3; }
        .bento-cell--status { grid-column: 3 / 4; }
        .bento-cell--render1 { grid-column: 1 / 2; }
        .bento-cell--render2 { grid-column: 2 / 3; }
        .bento-cell--pipeline { grid-column: 3 / 4; }
        .bento-cell--stack { grid-column: 1 / 3; }
        .bento-cell--cta { grid-column: 3 / 4; }

        /* Code */
        .bento-code { height: 100%; display: flex; flex-direction: column; background: #0A0F0A; min-height: 260px; }
        .bento-code__header {
          display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem 1rem;
          border-bottom: 1px solid rgba(255,255,255,0.06); flex-shrink: 0;
        }
        .bento-code__circles { display: flex; gap: 5px; }
        .bento-code__body {
          flex: 1; padding: 1rem; font-family: 'JetBrains Mono', monospace;
          font-size: 0.72rem; line-height: 1.8; overflow: hidden;
        }
        .bento-code__line { white-space: pre; }
        .bento-cursor {
          width: 7px; height: 14px; background: var(--cyan);
          animation: blink 1s step-end infinite; margin-top: 2px;
          box-shadow: 0 0 8px var(--cyan);
        }
        @keyframes blink { 0%,100%{opacity:1}50%{opacity:0} }

        /* Status */
        .bento-status { padding: 1.25rem; display: flex; flex-direction: column; gap: 1rem; height: 100%; min-height: 260px; }
        .bento-status__header { display: flex; justify-content: space-between; align-items: center; }
        .bento-status__pulse {
          width: 8px; height: 8px; border-radius: 50%; background: #22C55E;
          box-shadow: 0 0 8px #22C55E; animation: statusPulse 2s ease-in-out infinite;
        }
        @keyframes statusPulse { 0%,100%{opacity:1}50%{opacity:0.4} }
        .bento-status__items { display: flex; flex-direction: column; gap: 0.6rem; flex: 1; }
        .bento-status__item { display: flex; justify-content: space-between; align-items: center; }
        .bento-status__footer { display: flex; justify-content: space-between; padding-top: 0.875rem; border-top: 1px solid var(--border); }

        /* Render */
        .bento-render {
          height: 180px; position: relative; overflow: hidden;
          display: flex; flex-direction: column;
        }
        .bento-render__bg {
          position: absolute; inset: 0;
          background: radial-gradient(circle at 70% 30%, var(--render-color, var(--cyan)) 0%, transparent 60%);
          opacity: 0.08;
        }
        .bento-render__grid {
          position: absolute; inset: 0;
          background-image: linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px);
          background-size: 30px 30px; opacity: 0.4;
        }
        .bento-render__content {
          position: relative; z-index: 1; padding: 1rem;
          display: flex; flex-direction: column; gap: 0.75rem; flex: 1; justify-content: flex-end;
        }
        .bento-render__tag {
          font-size: 0.58rem; border: 1px solid; border-radius: 100px;
          padding: 0.2rem 0.6rem; align-self: flex-start;
        }
        .bento-render__play {
          width: 40px; height: 40px; border-radius: 50%;
          border: 1px solid var(--render-color, var(--cyan));
          display: flex; align-items: center; justify-content: center;
          background: rgba(0,0,0,0.5); position: absolute; top: 50%; right: 1rem; transform: translateY(-50%);
          transition: transform 0.3s;
        }
        .bento-render:hover .bento-render__play { transform: translateY(-50%) scale(1.1); }
        .bento-render__badge {
          position: absolute; top: 1rem; right: 1rem;
          font-family: 'JetBrains Mono', monospace; font-size: 0.58rem;
          color: var(--text-tertiary); letter-spacing: 0.1em;
        }

        /* Pipeline */
        .bento-pipeline { padding: 1.25rem; display: flex; flex-direction: column; gap: 0.875rem; }
        .bento-pipeline__header { display: flex; justify-content: space-between; align-items: center; }
        .bento-pipeline__steps { display: flex; flex-direction: column; gap: 0.6rem; }
        .bento-pipeline__step { display: flex; align-items: center; gap: 0.6rem; }
        .bento-pipeline__step-dot {
          width: 8px; height: 8px; border-radius: 50%; border: 1px solid; flex-shrink: 0;
        }
        @keyframes stepPulse { 0%,100%{opacity:1;transform:scale(1)}50%{opacity:0.5;transform:scale(1.3)} }

        /* Stack */
        .bento-stack { padding: 1.25rem; display: flex; flex-direction: column; height: 100%; }
        .bento-stack__badges { display: flex; flex-wrap: wrap; gap: 0.5rem; }
        .bento-badge {
          display: flex; align-items: center; gap: 0.5rem;
          padding: 0.5rem 0.875rem; border: 1px solid var(--border);
          border-radius: 8px; background: var(--bg-3); transition: all 0.2s;
          position: relative;
        }
        .bento-badge:hover { border-color: var(--badge-color, var(--cyan)); background: var(--surface); }
        .bento-badge__dot {
          width: 6px; height: 6px; border-radius: 50%;
          background: #22C55E; margin-left: auto; flex-shrink: 0;
        }

        /* CTA */
        .bento-cta { padding: 1.5rem; display: flex; flex-direction: column; height: 100%; position: relative; overflow: hidden; }
        .bento-cta__orb {
          position: absolute; width: 200px; height: 200px;
          background: radial-gradient(circle, rgba(0,229,255,0.1) 0%, transparent 70%);
          top: -60px; right: -60px; border-radius: 50%; pointer-events: none;
        }

        @media (max-width: 900px) {
          .bento-grid { grid-template-columns: 1fr 1fr; }
          .bento-cell--code { grid-column: 1 / -1; }
          .bento-cell--status { grid-column: 1 / -1; }
          .bento-cell--pipeline { grid-column: 1 / -1; }
          .bento-cell--stack { grid-column: 1 / -1; }
          .bento-cell--cta { grid-column: 1 / -1; }
        }
        @media (max-width: 600px) {
          .bento-grid { grid-template-columns: 1fr; }
          .bento-cell--render1, .bento-cell--render2 { grid-column: 1; }
        }
      `}</style>
    </section>
  );
}
