export const SITE = {
  name: 'AIPGBD',
  tagline: 'AI Playground BD',
  facebook: 'https://facebook.com/aipgbd',
  youtube: 'https://youtube.com/@aipgbd',
  email: 'hello@aipgbd.com',
  whatsapp: 'https://wa.me/8801XXXXXXXXX',
};

export const STATS = [
  { num: '30', unit: 's', label: 'Unbroken cinematic take' },
  { num: '72', unit: 'h', label: 'Brief to delivery' },
  { num: '80', unit: '%', label: 'Less than traditional' },
  { num: '5', unit: 'x', label: 'Production stack depth' },
];

export const PACKAGES = [
  {
    id: 'spark',
    num: '01',
    title: 'The Spark',
    desc: 'One 30-second cinematic product or brand video with a custom AI-composed background score and professional voiceover. Delivered in 48 hours.',
    price: '8,000',
    currency: 'BDT',
    unit: 'per video',
    features: [
      '1 × 30s cinematic video',
      'Custom Suno audio score',
      'ElevenLabs voiceover (30s)',
      '48-hour delivery',
      'Commercial rights included',
      '1 revision round',
    ],
  },
  {
    id: 'engine',
    num: '02',
    title: 'The Brand Engine',
    desc: 'Three cinematic videos, a portfolio website with video hero, full brand audio identity, and voiceover narration across all assets.',
    price: '25,000',
    currency: 'BDT',
    unit: 'full kit',
    popular: true,
    features: [
      '3 × 30s cinematic videos',
      '3-page website with video hero',
      'Full brand audio identity',
      'ElevenLabs brand voice (cloned)',
      '72-hour delivery',
      'Commercial rights included',
      '2 revision rounds',
    ],
  },
  {
    id: 'retainer',
    num: '03',
    title: 'Agency Retainer',
    desc: '8 cinematic videos per month, website maintenance, weekly content calendar, and dedicated voiceover in your brand voice. Your production department.',
    price: '40,000',
    currency: 'BDT',
    unit: '/ month',
    features: [
      '8 × cinematic videos monthly',
      'Website maintenance',
      'Weekly content calendar',
      'ElevenLabs voice — unlimited',
      'Priority 24h delivery',
      'Unlimited revisions',
      'Dedicated WhatsApp line',
    ],
  },
];

export const PROCESS = [
  {
    tool: 'Gemini',
    step: '01',
    color: '#4285F4',
    title: 'Visual Anchor',
    desc: 'Hyper-realistic base image. 8K resolution. Arri Alexa colour grade. The photographic foundation every frame builds on.',
    detail: 'We craft precise visual anchors using cinematic lighting language — Rembrandt ratios, anamorphic bokeh, atmospheric haze. The anchor image is the blueprint.',
  },
  {
    tool: 'Grok',
    step: '02',
    color: '#00C2FF',
    title: 'Motion Extension',
    desc: 'The anchor animates into 30 unbroken seconds of cinematic motion. 24fps. No cuts. No transitions.',
    detail: 'Using the anchor-and-extend method, we keyframe-bridge scenes to maintain absolute visual consistency across the full duration. Character faces never morph.',
  },
  {
    tool: 'Suno',
    step: '03',
    color: '#FF6B35',
    title: 'Original Score',
    desc: 'A custom brand audio track composed to match your visuals exact tempo, mood, and emotional register.',
    detail: 'Every score is mastered to broadcast standards. We specify BPM, instrumentation, and emotional arc to match your brand voice — not a stock track.',
  },
  {
    tool: 'ElevenLabs',
    step: '04',
    color: '#A855F7',
    title: 'Brand Voiceover',
    desc: 'Professional AI voiceover in any language, tone, or accent. Clone your own voice for brand consistency across all assets.',
    detail: 'We engineer the perfect voice profile for your brand — warm, authoritative, or aspirational. Full Bangla, English, and multilingual support. Voice cloning available on Engine and Retainer plans.',
  },
  {
    tool: 'Claude',
    step: '05',
    color: '#D4A853',
    title: 'Direction & Code',
    desc: 'Creative direction, prompt engineering, scripting, and website development. The intelligence binding every tool.',
    detail: 'Every project begins with a Claude-generated creative brief that defines character seed, lighting language, audio brief, and voiceover script before a single tool is activated.',
  },
];

export const NICHES = [
  { icon: '🏢', title: 'Real Estate', pain: 'Spending 1.5L BDT on a single shoot to sell apartments that do not exist yet.', roi: 'Cinematic pre-sale tours from architectural renders. 25K vs 1.5L BDT.' },
  { icon: '⚡', title: 'Fintech & Startups', pain: 'Founders needing investor-grade brand identity in days, not months.', roi: 'Full brand kit in 72 hours. Investor-ready by Friday.' },
  { icon: '✦', title: 'Luxury E-commerce', pain: 'Fashion brands losing sales because their video content looks like a phone recording.', roi: 'International-grade product cinema at local market prices.' },
  { icon: '🍽', title: 'F&B Restaurants', pain: 'Premium restaurants needing 8 pieces of content monthly but one crew shoot costs the entire ad budget.', roi: '8 cinematic videos monthly at 15,000 BDT retainer.' },
  { icon: '◈', title: 'SME Brand Launch', pain: 'Newly formalized businesses needing to look legitimate fast without the agency queue or price tag.', roi: 'Website, video, and audio identity in one 72-hour package.' },
  { icon: '⬡', title: 'Virtual Influencers', pain: 'Brands needing a permanent AI face that never ages, never has scandals, and appears in 10 videos simultaneously.', roi: 'Character bible: 50 images, 5 clips, voice clone. 25K BDT.' },
];

export const FAQS = [
  { q: 'Can I legally use the content you produce?', a: 'Yes. All work is delivered with full commercial rights. Our Suno, Grok, Gemini, and ElevenLabs accounts run on paid commercial tiers so your brand owns everything we create. No copyright strikes, no licensing issues. We document this in a simple one-page service agreement.' },
  { q: 'Is this actually AI or did a real designer make it?', a: 'Both. AI-engineered production, human-directed vision. The tools generate — we direct, compose, and refine. Your taste and our direction are the product. The AI is the production infrastructure.' },
  { q: 'What if I do not like the result?', a: 'Every package includes at least one free revision round. We have never had a client not proceed to final delivery. The revision guarantee means you take zero risk on the first engagement.' },
  { q: 'How do I pay?', a: 'bKash, Nagad, or bank transfer. 50% deposit to begin, 50% on delivery. We will never ask for full payment before you have seen and approved the work.' },
  { q: 'How long does it actually take?', a: 'The Spark: 48 hours from brief to delivery. The Brand Engine: 72 hours. The Retainer: videos delivered on a weekly content calendar you approve at the start of each month.' },
  { q: 'Can you produce voiceover in Bangla?', a: 'Yes. ElevenLabs supports full Bangla voiceover with natural intonation. We can also produce multilingual versions — Bangla and English — of the same asset for dual-market campaigns.' },
  { q: 'Do you work with brands outside Dhaka?', a: 'Yes. We work remotely with brands across Bangladesh. For real estate clients, all we need are your architectural renders or existing product photography. No physical access required.' },
];
