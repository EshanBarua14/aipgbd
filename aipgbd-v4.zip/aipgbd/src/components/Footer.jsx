export default function Footer({ db }) {
  const s = db?.site || {};
  return (
    <footer className="footer">
      <div className="footer__top">
        <div className="container footer__top-inner">
          <div className="footer__brand">
            <img src={s.logoUrl||'/logo.png'} alt={s.name} className="footer__logo" onError={e=>{e.target.style.display='none'}} />
            <div>
              <div className="footer__name">{s.name||'AI Playground BD'}</div>
              <div className="footer__tagline t-label" style={{color:'var(--text-tertiary)'}}>{s.tagline||'AI-Engineered · Human-Directed'}</div>
            </div>
          </div>
          <div className="footer__links-grid">
            <div className="footer__col">
              <div className="footer__col-title t-label">Services</div>
              {(db.packages||[]).map(p=><a key={p.id} href="#services" className="footer__link">{p.title}</a>)}
            </div>
            <div className="footer__col">
              <div className="footer__col-title t-label">Industries</div>
              {(db.industries||[]).slice(0,4).map(n=><a key={n.id} href="#industries" className="footer__link">{n.title}</a>)}
            </div>
            <div className="footer__col">
              <div className="footer__col-title t-label">Connect</div>
              {s.facebook && <a href={s.facebook} target="_blank" rel="noreferrer" className="footer__link">Facebook</a>}
              {s.youtube && <a href={s.youtube} target="_blank" rel="noreferrer" className="footer__link">YouTube</a>}
              {s.instagram && <a href={s.instagram} target="_blank" rel="noreferrer" className="footer__link">Instagram</a>}
              {s.email && <a href={`mailto:${s.email}`} className="footer__link">Email</a>}
            </div>
          </div>
        </div>
      </div>
      <div className="footer__bar">
        <div className="container footer__bar-inner">
          <span className="t-label" style={{color:'var(--text-tertiary)',fontSize:'0.58rem'}}>© 2026 {s.name||'AI Playground BD'} · Dhaka, Bangladesh</span>
          <div style={{flex:1,height:1,background:'linear-gradient(to right,var(--cyan-border),var(--purple-border),transparent)'}}/>
          <span className="t-label" style={{color:'var(--text-tertiary)',fontSize:'0.58rem'}}>Gemini · Grok · Suno · ElevenLabs · Claude</span>
        </div>
      </div>
      <style>{`
        .footer{border-top:1px solid var(--border)}
        .footer__top{padding:4rem 0}
        .footer__top-inner{display:flex;gap:4rem;align-items:flex-start;flex-wrap:wrap}
        .footer__brand{display:flex;align-items:center;gap:1rem;flex-shrink:0}
        .footer__logo{width:44px;height:44px;border-radius:50%;border:1px solid var(--cyan-border)}
        .footer__name{font-family:'Outfit',sans-serif;font-weight:700;font-size:0.95rem;color:var(--text-primary)}
        .footer__links-grid{display:flex;gap:3rem;flex-wrap:wrap;margin-left:auto}
        .footer__col{display:flex;flex-direction:column;gap:0.6rem}
        .footer__col-title{color:var(--text-tertiary);margin-bottom:0.25rem}
        .footer__link{font-size:0.82rem;color:var(--text-secondary);transition:color 0.2s}
        .footer__link:hover{color:var(--cyan)}
        .footer__bar{border-top:1px solid var(--border);padding:1.25rem 0}
        .footer__bar-inner{display:flex;align-items:center;gap:1.5rem}
      `}</style>
    </footer>
  );
}
